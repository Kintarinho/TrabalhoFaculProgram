package com.example.trabalhofacul;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private EditText Nome;
    private EditText Email;
    private EditText Idade;
    private EditText Disci;
    private EditText Nota1;
    private EditText Nota2;
    private TextView Erro;
    private TextView Final;
    private Button Enviar;
    private Button Excluir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Nome = findViewById(R.id.Nome);
        Email = findViewById(R.id.Email);
        Idade = findViewById(R.id.Idade);
        Disci = findViewById(R.id.Disci);
        Nota1 = findViewById(R.id.Nota1);
        Nota2 = findViewById(R.id.Nota2);
        Erro = findViewById(R.id.Erro);
        Final = findViewById(R.id.Final);
        Enviar = findViewById(R.id.Enviar);
        Excluir = findViewById(R.id.Excluir);

        Enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("DEBUG", "Botão Enviar foi clicado");
                validarFormulario();
            }
        });

        Excluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                excluirFormulario();
            }
        });

     



    }
    private void validarFormulario(){
    String nomeresult = Nome.getText().toString();
    String emailresult = Email.getText().toString();
    String idaderesult = Idade.getText().toString();
    String disciresult = Disci.getText().toString();
    float nota1result = Float.parseFloat(Nota1.getText().toString());
    float nota2result = Float.parseFloat(Nota2.getText().toString());

        StringBuilder erros = new StringBuilder();


        if (nomeresult.isEmpty()) erros.append("O campo de nome está vazio.\n");
        if (emailresult.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(emailresult).matches()) {
            erros.append("O email é inválido.\n");
        }

        int idade = -1;
        try {
            idade = Integer.parseInt(idaderesult);
            if (idade <= 0) {
                erros.append("A idade deve ser um número positivo.\n");
            }
        } catch (NumberFormatException e) {
            erros.append("A idade deve ser um número válido.\n");
        }

        float nota1 = -1, nota2 = -1;
        if (Nota1.getText().toString().isEmpty()) {
            erros.append("Nota 1 está vazia.\n");
        } else {
            try {
                nota1 = Float.parseFloat(String.valueOf(nota1result));
                if (nota1 < 0 || nota1 > 10) {
                    erros.append("Nota 1º Bimestre deve estar entre 0 e 10.\n");
                }
            } catch (NumberFormatException e) {
                erros.append("Nota 1º Bimestre deve ser um número válido.\n");
            }
        }


        try {
            nota2 = Float.parseFloat(String.valueOf(nota2result));
            if (nota2 < 0 || nota2 > 10) {
                erros.append("2º Nota Bimestre deve estar um número valido entre 0 e 10.\n");
            }
        } catch (NumberFormatException e) {
            erros.append("Nota 2º Bimestre deve ser um número válido.\n");
        }

        if (erros.length() > 0) {
            Erro.setVisibility(View.VISIBLE);
            Erro.setText(erros.toString());
            Final.setVisibility(View.GONE);
        } else {
            Erro.setVisibility(View.GONE);
            float media = (nota1 + nota2) / 2;
            String status = media >= 6 ? "Aprovado" : "Reprovado";

            String finalz = "Nome: " + nomeresult + "\n" +
                    "Email: " + emailresult + "\n" +
                    "Idade: " + idade + "\n" +
                    "Materia: " + disciresult + "\n" +
                    "Notas dos Bimestres: " + nota1 + ", " + nota2 + "\n" +
                    "Média: " + media + "\n" +
                    "Status: " + status;

            Final.setVisibility(View.VISIBLE);
            Final.setText(finalz);
        }
    }

    private void excluirFormulario() {
        Nome.setText("");
        Email.setText("");
        Idade.setText("");
        Disci.setText("");
        Nota1.setText("");
        Nota2.setText("");
        Erro.setVisibility(View.GONE);
        Final.setVisibility(View.GONE);
    }
}
